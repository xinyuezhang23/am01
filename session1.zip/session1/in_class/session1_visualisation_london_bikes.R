library(tidyverse)
# install.packages("mosaic") # in case you haven't installed the mosaic package
library(mosaic)
library(here)
library(lubridate)


#read the CSV file
bike <- read_csv(here::here("Data", "londonBikes.csv"))

# fix dates using lubridate, and generate new variables for year, month, month_name, day, and day_of _week
bike <- bike %>%   
  mutate(
    date=dmy(date),
    year=year(date),
    month = month(date),
    month_name=month(date, label = TRUE),
    day = day(date),
    day_of_week = wday(date, label = TRUE)) 

# generte new variable season_name to turn seasons from numbers to Winter, Spring, etc
bike <- bike %>%  
  mutate(
    season_name = case_when(
      season == 1 ~ "Winter",
      season == 2 ~ "Spring",
      season == 3 ~ "Summer",
      season == 4 ~ "Autumn"
    ),
    
    #relevel the factor, otherwise it would have seasons in alphabetical order
    season_name = fct_relevel(season_name, "Winter", "Spring", "Summer", "Autumn")
  )

# examine what the resulting data frame looks like
glimpse(bike)

#summary statistics
favstats(~ avg_temp, data= bike)

# if we wanted to get summary statistics by `year`, `day_of_week`,  `month_name`, or `season_name`
# we use mosaic's syntax `Y ~ X` that allows us to facet our analysis of a variable Y by variable X 
# using the syntax `favstats( Y ~ Z, data=...)`

favstats(avg_temp ~ year, data=bike)
favstats(avg_temp ~ day_of_week, data=bike)
favstats(avg_temp ~ month_name, data=bike)
favstats(avg_temp ~ season_name, data=bike)


# Histogram of average temperature in London
ggplot(bike, aes(x=avg_temp))+
  geom_histogram()+
  theme_bw()+
  NULL

# Histogram faceted by season_name
ggplot(bike, aes(x=avg_temp))+
  geom_histogram()+
  facet_wrap(~season_name)+
  theme_bw()+
  NULL

# Histogram faceted by month_name
ggplot(bike, aes(x=avg_temp))+
  geom_histogram()+
  facet_wrap(~month_name)+
  theme_bw()+
  NULL

# Histogram faceted by month_name in 4 rows
ggplot(bike, aes(x=avg_temp))+
  geom_histogram()+
  facet_wrap(~month_name, nrow = 4)+
  theme_bw()+
  NULL


# Density plot of average temperature in London
ggplot(bike, aes(x=avg_temp))+
  geom_density()+
  theme_bw()+
  NULL

# Density plot of average temperature, filled by season_name 
ggplot(bike, aes(x=avg_temp))+
  geom_density(aes(fill=season_name, alpha = 0.3))+
  theme_bw()+
  NULL

# Density plot of average temperature, filled by season_name, and faceted by season_name
ggplot(bike, aes(x=avg_temp))+
  geom_density(aes(fill=season_name, alpha = 0.3))+
  facet_wrap(~season_name, nrow = 4)+
  theme_bw()+
  NULL

# Density plot of average temperature, filled by season_name, and faceted by month_name
ggplot(bike, aes(x=avg_temp))+
  geom_density(aes(fill=season_name, alpha = 0.3))+
  facet_wrap(~month_name, nrow = 4)+
  theme_bw()+
# theme(legend.position="none")+
  NULL

#Boxplot of average temperature by month
# since 'month' is a number, it treats it as a continuous variable; hence we get just one box
ggplot(bike, aes(x=month, y= avg_temp))+
  geom_boxplot()+
  theme_bw()+
  NULL


#Boxplot of average temperature by month_name
ggplot(bike, aes(x=month_name, y= avg_temp))+
  geom_boxplot()+
  theme_bw()+
  NULL


#Boxplot of average temperature by month_name
ggplot(bike, aes(x=month_name, y= avg_temp, fill=season_name))+
  geom_boxplot()+
  theme_bw()+
  NULL


#Violin plot of average temperature by month_name
ggplot(bike, aes(x=month_name, y= avg_temp))+
  geom_violin()+
  theme_bw()+
  NULL


#### Further exercises to try on your own

# 1. Manually create a toy data frame ----
toy_data <- data_frame(
  x = c(1, 2, 3, 4, 5),
  y = c(5, 4, 3, 2, 1),
  count = c(10, 20, 30, 40, 50),
  group = c("A", "B", "C", "D", "E")
)

toy_data


# 2. Scatterplots: mapping group to color aesthetic ----
# 2.a) Simple scatterplot with size set to 5 for all points (i.e. not mapping
# to a variable in toy_data)
ggplot(toy_data, aes(x = x, y = y)) +
  geom_point(size = 5)

# 2.b) Default color scheme: map group variable to color
ggplot(toy_data, aes(x = x, y = y, colour = group)) +
  geom_point(size = 5)

# 2.c) Change color palette from default to "Set2": No assumed ordering to group
ggplot(toy_data, aes(x = x, y = y, color = group)) +
  geom_point(size = 5) +
  scale_color_brewer(palette = "Set2")

# scale_color_brewer palettesthat are available for use with these scales:
#   
# Diverging Scale
# BrBG, PiYG, PRGn, PuOr, RdBu, RdGy, RdYlBu, RdYlGn, Spectral
# 
# Qualitative Scale
# Accent, Dark2, Paired, Pastel1, Pastel2, Set1, Set2, Set3
# 
# Sequential Scale
# Blues, BuGn, BuPu, GnBu, Greens, Greys, Oranges, OrRd, PuBu, PuBuGn, PuRd, Purples, RdPu, Reds, YlGn, YlGnBu, YlOrBr, YlOrRd


# 2.d) Change color palette from default to "Blues": Assumed ordering to group
ggplot(toy_data, aes(x = x, y = y, color = group)) +
  geom_point(size = 5) +
  scale_color_brewer(palette = "Blues")

# 3. Barplots: mapping group to fill aesthetic ----
# 3.a) Simple barplot
ggplot(toy_data, aes(x = group, y = count)) +
  geom_col()

# 3.b) colour aesthetic is the outline of bars
ggplot(toy_data, aes(x = group, y = count, colour = group)) +
  geom_col()

# 3.c) The color of bars corresponds to fill aesthetic
ggplot(toy_data, aes(x = group, y = count, fill = group)) +
  geom_col()

# 3.d) Change color palette from default to "Set2": No assumed ordering to group
ggplot(toy_data, aes(x = group, y = count, fill = group)) +
  geom_col() +
  scale_fill_brewer(palette = "Set1")

# 3.e) Change color palette from default to "YlOrBr": Assumed ordering to group
ggplot(toy_data, aes(x = group, y = count, fill = group)) +
  geom_col() +
  scale_fill_brewer(palette = "YlOrBr")
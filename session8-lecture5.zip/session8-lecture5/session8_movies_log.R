library(tidyverse)
library(data.table)
library(skimr)
library(broom)
library(lubridate)
library(GGally)
library(kableExtra)
library(huxtable)
library(car)
library(ggfortify)


movies <- read_csv(here("data", "movies.csv"))

ggplot(movies, aes(x=gross))+
  geom_density()

ggplot(movies, aes(x=log(gross)))+
  geom_density()


ggplot(movies, aes(x=budget))+
  geom_density()
ggplot(movies, aes(x=log(budget)))+
  geom_density()

model1 <- lm(gross ~ 1, data=movies)
model2 <- lm(gross ~ budget, data=movies)
model3 <- lm(log(gross) ~ log(budget), data=movies)

huxreg(model1, model2, model3, 
       statistics = c('#observations' = 'nobs', 
                      'R squared' = 'r.squared', 
                      'Adj. R Squared' = 'adj.r.squared's, 
                      'Residual SE' = 'sigma'), 
       bold_signif = 0.05, 
       stars = NULL
) %>% 
  set_caption('Comparison of models')

autoplot(model2)
autoplot(model3)

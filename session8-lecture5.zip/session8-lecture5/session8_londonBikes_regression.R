library(tidyverse)
library(data.table)
library(skimr)
library(broom)
library(lubridate)
library(GGally)
library(kableExtra)
library(huxtable)
library(car)
library(here)


bikes <- read_csv(here("data", "londonBikes.csv")) %>% 
  mutate(
    id = row_number(),
    date=dmy(date),
    year=year(date),
    month = month(date),
    month_name=month(date, label = TRUE),
    day = wday(date, week_start = 1),
    day_of_week = wday(date, label = TRUE,week_start = 1),
    # need to mutate (or turn) seasons from numbers to Winter, Spring, etc
    season_name = case_when(
      season == 1 ~ "Winter",
      season == 2 ~ "Spring",
      season == 3 ~ "Summer",
      season == 4 ~ "Autumn"
    ),
    season_name = fct_relevel(season_name, "Winter", "Spring", "Summer", "Autumn")
  ) %>% 
  filter(year<2020)


bikes %>% select(bikes_hired) %>% skim()
# Mean bikes hired = 26269, SD=9004

model1 <- lm (bikes_hired ~ 1, data = bikes)
tidy(model1)
glance(model1)
anova(model1)


ggplot(bikes, aes(x=id, y =bikes_hired))+
  geom_point()+
  geom_smooth(method = "lm", se=FALSE)

model2 <- lm (bikes_hired ~ id + season, data = bikes)
tidy(model2)
glance(model2)
anova(model2)

model3 <- lm (bikes_hired ~ id + season_name, data = bikes)
tidy(model3)
glance(model3)
anova(model3)

model3 <- lm (bikes_hired ~ id + season_name + factor(day) + factor(month), data = bikes)
tidy(model4)
glance(model4)

model4 <- lm (bikes_hired ~ id + season_name + factor(day) + factor(month) + avg_temp, data = bikes)
tidy(model4)
glance(model4)

model5 <- lm (bikes_hired ~ id + season_name + factor(day) + factor(month) + avg_temp + avg_humidity + avg_pressure + avg_windspeed + rainfall_mm, data = bikes)
tidy(model5)
glance(model5)


bikes_ggpairs <- bikes %>% 
  select(avg_temp, avg_humidity, avg_pressure, avg_windspeed, bikes_hired) %>% 
  ggpairs()

bikes_ggpairs


model6 <- lm (bikes_hired ~ id + season_name + factor(day) + avg_temp + avg_humidity + avg_pressure + avg_windspeed + rainfall_mm, data = bikes)
tidy(model6)
glance(model6)

model7 <- lm (bikes_hired ~ id  + factor(day) + avg_temp + avg_humidity + avg_pressure + avg_windspeed + rainfall_mm, data = bikes)
tidy(model7)
glance(model7)


huxreg(model1,  model3, model4, model5, model6, model7,
       statistics = c('#observations' = 'nobs', 
                      'R squared' = 'r.squared', 
                      'Adj. R Squared' = 'adj.r.squared', 
                      'Residual SE' = 'sigma'), 
       bold_signif = 0.05, 
       stars = NULL
) %>% 
  set_caption('Comparison of models')


anova(model7)
aov(model7)


vif(model3)
vif(model4)
vif(model5)
vif(model6)
vif(model7)
vif(model8)
